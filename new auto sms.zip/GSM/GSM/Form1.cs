﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using GsmComm.PduConverter;
using GsmComm.PduConverter.SmartMessaging;
using GsmComm.GsmCommunication;
using GsmComm.Interfaces;
using GsmComm.Server;
using System.Globalization;
using MySql.Data.MySqlClient;

namespace GSM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private GsmCommMain comm;
        SmsServer smsserver;

        public object ConfigurationManager { get; private set; }

        private void button1_Click(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                SmsSubmitPdu pdu;
                byte dcs = (byte)DataCodingScheme.GeneralCoding.Alpha7BitDefault;
                pdu = new SmsSubmitPdu(richTextBox1.Text, Convert.ToString(textBox2.Text), dcs);
                int time = 1;
                for (int i = 0; i < time; i++)
                {
                    comm.SendMessage(pdu);

                }
                MessageBox.Show("Message is Successfully Sent.","Message Sent",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch (Exception)
            {
                
                MessageBox.Show("Message is Not Sent Pleaz try Again.","Message Not Sent",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.send_all_sms();
          
        }

        public void send_all_sms()
        {
            //string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=sms;";
            // Your query,
            string connectionString =
    System.Configuration.ConfigurationManager.
    ConnectionStrings["connect"].ConnectionString;

            string limit = System.Configuration.ConfigurationManager.
    ConnectionStrings["limit"].ConnectionString;
            string branch_id = System.Configuration.ConfigurationManager.
    ConnectionStrings["branch_id"].ConnectionString;
            string query;
            if (branch_id.Contains("0"))
            {
                query = "SELECT * FROM sms where status ='0' AND branch_id='" + branch_id + "' Limit " + limit;
            }
            else
            {
                query = "SELECT * FROM sms where status ='0' Limit " + limit;
            }



            // Prepare the connection
            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;
            MySqlDataReader reader;
            progressBar1.Visible = true;
            // Let's do it !
            try
            {
                // Open the database
                databaseConnection.Open();

                // Execute the query
                reader = commandDatabase.ExecuteReader();

                // All succesfully executed, now do something

                // IMPORTANT : 
                // If your query returns result, use the following processor :

                if (reader.HasRows)
                {
                    progressBar1.Maximum = this.Count();



                    int smscount = 0;
                    while (reader.Read())
                    {
                        // As our database, the array will contain : ID 0, FIRST_NAME 1,LAST_NAME 2, ADDRESS 3
                        // Do something with every received database ROW
                        string nameValue = reader["mobile_no"].ToString();
                        string classValue = reader["message"].ToString();
                        string id = reader["sms_id"].ToString();

                        Cursor.Current = Cursors.WaitCursor;
                        try
                        {
                            SmsSubmitPdu pdu;
                            byte dcs = (byte)DataCodingScheme.GeneralCoding.Alpha7BitDefault;
                            pdu = new SmsSubmitPdu(classValue, nameValue, dcs);
                            int time = 1;
                            for (int i = 0; i < time; i++)
                            {
                                comm.SendMessage(pdu);
                                this.Update_sms(id);
                                smscount += 1;
                                progressBar1.Step = 1;



                                progressBar1.PerformStep();

                            }


                        }
                        catch (Exception)
                        {

                            MessageBox.Show("Message Not Sent Pleaz try Again.", "Message Not Sent", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                            this.not_send(id);

                            break;


                        }









                    }

                    //here we show message box

                    MessageBox.Show(smscount + " Messages Successfully Sent", "Message Sent", MessageBoxButtons.OK, MessageBoxIcon.Information);





                    progressBar1.Value = 0;
                    progressBar1.Visible = false;

                }
                else
                {
                    MessageBox.Show("No Pending SMS Found.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    progressBar1.Visible = false;
                }

                // Finally close the connection


                databaseConnection.Close();
            }
            catch (Exception ex)
            {
                // Show any error message.
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            label5.Text = "Pending SMS = " + this.Count();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                VisitLink();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open link that was clicked.", "Unable to open",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }
        private void VisitLink()
        {
            // Change the color of the link text by setting LinkVisited   
            // to true.  
            linkLabel1.LinkVisited = true;
            //Call the Process.Start method to open the default browser   
            //with a URL:  
            System.Diagnostics.Process.Start("http://www.tapsol.com");
        }


        System.Timers.Timer time = new System.Timers.Timer();
        
        


        private void Form1_Load(object sender, EventArgs e)
        {
            
            string com = System.Configuration.ConfigurationManager.
   ConnectionStrings["com_port"].ConnectionString;
            string time_iinterval = System.Configuration.ConfigurationManager.
 ConnectionStrings["time_in_milisecond"].ConnectionString;


            if (com == "")
            {
                MessageBox.Show("Invalid port number", "Invalid Port", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            comm = new GsmCommMain(com, 9600, 150);
            Cursor.Current = Cursors.Default;

            bool retry;
            do
            {
                retry = false;
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    comm.Open();
                    Cursor.Current = Cursors.Default;
                    
                    timer1.Enabled = true;
                    timer1.Interval = Convert.ToInt32(time_iinterval);
                    timer1.Start();

                    
                    label7.Text = "Ready...";

                }
                catch (Exception)
                {
                    Cursor.Current = Cursors.Default;
                    if (MessageBox.Show(this, "GSM modem is not available", "check", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning) == DialogResult.Retry)

                        retry = true;

                    else
                    {
                        label7.Text = "Not Contected Pleaz try Again.";
                        return;
                    }


                }

            } while (retry);
            
            label5.Text = "Pending SMS = " + this.Count();
           
            progressBar1.Visible = false;

            





        }
        


        public void not_send(string id)
        {
            // string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=sms;";
            // Your query,
            string connectionString =
    System.Configuration.ConfigurationManager.
    ConnectionStrings["connect"].ConnectionString;
            string query = "UPDATE sms SET status='0' WHERE sms_id ='" + Convert.ToInt64(id) + "'";

            // Prepare the connection
            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;
            MySqlDataReader reader;







            // Let's do it !
            try
            {
                // Open the database
                databaseConnection.Open();

                // Execute the query
                reader = commandDatabase.ExecuteReader();

                // All succesfully executed, now do something

                // IMPORTANT : 
                // If your query returns result, use the following processor :


                // As our database, the array will contain : ID 0, FIRST_NAME 1,LAST_NAME 2, ADDRESS 3
                // Do something with every received database ROW




                // Finally close the connection

                databaseConnection.Close();
                
            }
            catch (Exception ex)
            {
                // Show any error message.
                MessageBox.Show(ex.Message,"unable to open Database",MessageBoxButtons.OK,MessageBoxIcon.Information);
               
            }


        }

        public int Count()
        {
            int smscount = 0;
            string connectionString =
   System.Configuration.ConfigurationManager.
   ConnectionStrings["connect"].ConnectionString;
           
            string branch_id = System.Configuration.ConfigurationManager.
   ConnectionStrings["branch_id"].ConnectionString;
            string query;
            if (branch_id.Contains("0"))
            {
                query = "Select sms_id from sms where status = '0' AND branch_id = '" + branch_id + "'";
            }
            else
            {
                query = "Select sms_id from sms where status = '0'";
            }
            // Prepare the connection
            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;
            MySqlDataReader reader;







            // Let's do it !
            try
            {
                // Open the database
                databaseConnection.Open();

                // Execute the query
                reader = commandDatabase.ExecuteReader();
                if (reader.HasRows)
                {
                    



                    
                    while (reader.Read())
                    {


                        smscount += 1;









                    }

                   

                }
                else
                {
                    
                   
                    
                }




                // Finally close the connection
                databaseConnection.Close();
                

            }
            catch (Exception ex)
            {
                // Show any error message.
                MessageBox.Show(ex.Message, "unable to open Database", MessageBoxButtons.OK, MessageBoxIcon.Information);


            }
            return smscount;
        }

       
        public int Update_sms(string sms_id)
        {

            //string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=sms;";
            // Your query,
            string connectionString =
    System.Configuration.ConfigurationManager.
    ConnectionStrings["connect"].ConnectionString;
            string query = "UPDATE sms SET status='1' WHERE sms_id ='" + Convert.ToInt32(sms_id) + "'";

            // Prepare the connection
            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;
            MySqlDataReader reader;

            
            
           

            

            // Let's do it !
            try
            {
                // Open the database
                databaseConnection.Open();

                // Execute the query
                reader = commandDatabase.ExecuteReader();

                // All succesfully executed, now do something

                // IMPORTANT : 
                // If your query returns result, use the following processor :


                // As our database, the array will contain : ID 0, FIRST_NAME 1,LAST_NAME 2, ADDRESS 3
                // Do something with every received database ROW




                // Finally close the connection
                
                databaseConnection.Close();
                return 1;
            }
            catch (Exception ex)
            {
                // Show any error message.
                MessageBox.Show(ex.Message, "unable to open Database", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return 0;
            }





        }

        
        
        protected override void OnFormClosing(FormClosingEventArgs e)
        {

            
          
            base.OnFormClosing(e);


            /*if (!e.Cancel)
            {
                if (MessageBox.Show("Do you want to close this application?", "Close Application", MessageBoxButtons.YesNo) != DialogResult.Yes)
                {

                   
                    e.Cancel = true;
                }
            }*/
            timer1.Stop();
            comm.Close();
            this.Dispose();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.send_all_sms();
        }
    }


}

